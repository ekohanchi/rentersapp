<?php

mysql_close();
?>