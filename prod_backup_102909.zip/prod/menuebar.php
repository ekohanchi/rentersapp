<?php
/*
 * Created on Oct 29, 2008
 *
 */
?>

<html>
<head>
</head>
<body>

<form>
<input style="color: blue; font-weight: bold" type=button onclick="document.location.href='admin.php'" value="Admin Tools">
<input style="color: green; font-weight: bold" type=button onclick="document.location.href='viewreferrals.php'" value="View Submitted Referrals">
<input style="color: black; font-weight: bold" type=button onclick="document.location.href='iplog.txt'" value="View IP Log - Viewed & Store Referral">
<!-- <input style="color: black; font-weight: bold" type=button onclick="document.location.href='iplog2.txt'" value="View IP Log - Viewed Referral"> -->
<br>
<input style="color: red; font-weight: bold" type=button onclick="document.location.href='renterreferral.php'" value="Submit New Referral">

</form>

</body>
</html>