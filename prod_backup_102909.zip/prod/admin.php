<?php
/*
 * Created on Sep 22, 2008
 *
 */
?>
<html>
<head>
<title>Renter Referral Admin</title>
</head>
<body>
<?php
include("login.php");
?>
<h1><center>Administrator Tools</center></h1>

<?php
include("menuebar.php");
?>
<input style="color: black; font-weight: bold" type=button onclick="document.location.href='admin.php?logout=1'" value="Logout">
</body>
</html>
